package com.cuevas.powerspike.service;

import com.cuevas.powerspike.dto.LcuChampSelectDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class LcuApi {

    private static final Logger log = LoggerFactory.getLogger(LcuApi.class);

    private final RestTemplate lcuRestTemplate;
    private final LcuLockfile lcuLockfile;
    private final LcuWebSocket lcuWebSocket;
    private final DataDragonClient dataDragonClient;
    private final GameStateService gameStateService;

    private String currentPhase = "CLOSED";
    private LcuChampSelectDTO currentChampSelect;
    private String champSelectError;

    public LcuApi(@Qualifier("lcuRestTemplate") RestTemplate lcuRestTemplate,
                  LcuLockfile lcuLockfile,
                  LcuWebSocket lcuWebSocket,
                  DataDragonClient dataDragonClient,
                  GameStateService gameStateService) {
        this.lcuRestTemplate = lcuRestTemplate;
        this.lcuLockfile = lcuLockfile;
        this.lcuWebSocket = lcuWebSocket;
        this.dataDragonClient = dataDragonClient;
        this.gameStateService = gameStateService;
    }

    @Scheduled(fixedDelay = 2000)
    public void pollPhase() {
        lcuLockfile.check();
        if (!lcuLockfile.isConnected()) {
            if (!"CLOSED".equals(currentPhase)) {
                currentPhase = "CLOSED";
                currentChampSelect = null;
                gameStateService.updatePhase("CLOSED");
                gameStateService.clearChampSelect();
            }
            return;
        }
        try {
            String phase = getPhase();
            if (phase != null && !phase.equals(currentPhase)) {
                currentPhase = phase;
                gameStateService.updatePhase(phase);

                if ("ChampSelect".equals(phase)) {
                    lcuWebSocket.connectToLCU();
                } else if (lcuWebSocket.isOpen()) {
                    lcuWebSocket.disconnect();
                }
            }

            if (!"ChampSelect".equals(currentPhase)) {
                if (currentChampSelect != null) {
                    currentChampSelect = null;
                    champSelectError = null;
                    gameStateService.clearChampSelect();
                }
            }

        } catch (Exception e) {
            currentPhase = "ERROR";
            gameStateService.updatePhase("ERROR");
        }
    }

    public String getPhase() {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", lcuLockfile.getAuth());
        HttpEntity<Void> entity = new HttpEntity<>(headers);

        String url = "https://127.0.0.1:" + lcuLockfile.getPort()
                + "/lol-gameflow/v1/gameflow-phase";

        try {
            ResponseEntity<String> response = lcuRestTemplate.exchange(
                    url, HttpMethod.GET, entity, String.class
            );
            String phase = response.getBody();
            if (phase != null) {
                phase = phase.replace("\"", "");
            }
            return phase;
        } catch (Exception e) {
            log.error("LCU getPhase error: {} - {}", e.getClass().getSimpleName(), e.getMessage());
            return null;
        }
    }

    public String refreshPhase() {
        lcuLockfile.check();
        if (!lcuLockfile.isConnected()) {
            currentPhase = "CLOSED";
            return "CLOSED (no lockfile)";
        }
        String phase = getPhase();
        if (phase != null) {
            currentPhase = phase;
            return phase;
        }
        return currentPhase + " (getPhase devolvió null)";
    }

    public void loadChampSelect() {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", lcuLockfile.getAuth());
        HttpEntity<Void> entity = new HttpEntity<>(headers);

        String url = "https://127.0.0.1:" + lcuLockfile.getPort()
                + "/lol-champ-select/v1/session";

        try {
            ResponseEntity<LcuChampSelectDTO> response = lcuRestTemplate.exchange(
                    url, HttpMethod.GET, entity, LcuChampSelectDTO.class
            );
            currentChampSelect = response.getBody();
            champSelectError = null;
        } catch (Exception e) {
            champSelectError = e.getClass().getSimpleName() + " - " + e.getMessage();
            currentChampSelect = null;
        }
    }

    public String refreshChampSelect() {
        champSelectError = null;
        currentChampSelect = null;
        loadChampSelect();
        if (currentChampSelect != null) return "OK";
        return champSelectError != null ? champSelectError : "null";
    }

    public void updateChampSelect(LcuChampSelectDTO data) {
        this.currentChampSelect = data;
        gameStateService.updateChampSelect(data);
    }

    public String getChampionName(long championId) {
        String name = dataDragonClient.getChampionName(championId);
        return name != null ? name : "Champion_" + championId;
    }

    public String getChampSelectError() { return champSelectError; }
    public String getCurrentPhase() { return currentPhase; }
    public LcuChampSelectDTO getCurrentChampSelect() { return currentChampSelect; }
    public boolean isInChampSelect() { return "ChampSelect".equals(currentPhase); }
}
